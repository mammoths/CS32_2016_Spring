#include <cassert>
#include "SSNSet.h"
#include <iostream>
using namespace std;

int main()
{
	SSNSet a;
	assert(a.add(400) && a.size() == 1);
	assert(!a.add(400) && a.size() == 1); //Cannot add another key, size remains 1. 
	assert(a.add(44) && a.size() == 2);// Adding successful 
	a.print(); // Prints line by line. 

	SSNSet b = a; // Copy Constructor test
	assert(b.size() == 2); // Same size. 
	
	SSNSet c; 
	c.add(999);
	c = b; 
	assert(c.size() == 2); // Assignment Operator pass. 

	cout << "All tests passed.";

}
