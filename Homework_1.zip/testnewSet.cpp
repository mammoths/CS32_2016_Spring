#include "newSet.h"
#include <iostream>
#include <cassert>
using namespace std;

void test()
{
	Set a(3);
	assert(a.insert(5) && a.size() == 1);
	assert(a.insert(10) && a.size() == 2);// insert working
	assert(!a.insert(5) && a.size() == 2); //should fail, size remains same
	assert(a.insert(15) && a.size() == 3); 
	assert(!a.insert(20) && a.size() == 3); // Fail to insert 4 items, size remains 3. 
	
	Set b = a; // Test Copy Constructor
	assert(b.size() == 3); 
	assert(b.contains(15)); 
	ItemType babies = 200; 
	assert(b.get(0, babies) && babies == 5); 

	Set c(1); 
	assert(c.insert(3000));

	// Test swap function

	c.swap(a); 

	assert(a.contains(3000) && !c.contains(3000) && a.size() == 1 && c.size() == 3);

	// Test assignment operator
	c = a; 

	assert(c.contains(3000) && c.size() == 1); 


	
}

int main()
{
	test();
	cout << "Passed all tests" << endl;
}
