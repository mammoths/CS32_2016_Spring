#include "SSNSet.h"
#include <iostream>


SSNSet::SSNSet() { }

bool SSNSet::add(unsigned long ssn) {

	if (SSN.insert(ssn))
		return true;
	else
		return false;

}
	// Add an SSN to the SSNSet.  Return true if and only if the SSN
	// was actually added.


int SSNSet::size() const
{
	return SSN.size(); 

}// Return the number of SSNs in the SSNSet.

void SSNSet::print() const {

	for (int i = 0; i < SSN.size(); i++) {
		ItemType a = 100;
		SSN.get(i, a);
		std::cout << a << std::endl;
	}

}


	// Write every SSN in the SSNSet to cout exactly once, one per
	// line.  Write no other text.

	