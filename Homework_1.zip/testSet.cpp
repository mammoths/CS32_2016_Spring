#include <cassert>
#include "Set.h"
#include <iostream>
using namespace std;

int main()
{
	Set a;
	assert(a.empty()); // Test empty function
	assert(a.insert(300) && a.contains(300) && a.size() == 1); // Test insert, contains, and size
	assert(!a.insert(300) && a.size() == 1); // Test no duplicates, size remains unchanged
	assert(!a.empty()); // Test empty function
	a.insert(20);
	a.insert(9);
	ItemType babies = 6009;
	assert(a.get(0, babies) && babies == 300);// value changes to index value 
	assert(!a.get(5000, babies) && babies == 300); //index out of range, babies unchanged. 
	
	
	Set b = a; 
	assert(b.size() == a.size()); // Copy Construction Test. Size and content are the same.
	assert(b.contains(300)); // Test same content. 




	Set c;
	c.insert(696969);
	c.swap(a);
	assert(a.contains(696969) && c.contains(300)); // Test Swap function
	assert(a.size() == 1); // test size swap

	c = a; // Assignment Operator Test
	assert(c.size() == a.size());
	assert(c.contains(696969)); //Test same content

	cerr << "All Tests Passed.";

}
