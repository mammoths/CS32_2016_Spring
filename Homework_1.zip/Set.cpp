#include "Set.h"
#include <iostream>


Set::Set() 
{
	m_size = 0;
	m_position = 0; 
}
	

bool Set::empty() const
{
	if (m_size == 0 )
		return true;
	else
		return false; 
}

int Set::size() const {
	return m_size; 
}

bool Set::insert(const ItemType& value) 
{
	if (m_size == DEFAULT_MAX_ITEMS)
		return false; 

	if (contains(value))
		return false; 
	
	m_array[m_size] = value; 
	m_size++;
	return true;

}
	// Insert value into the set if it is not already present.  Return
	// true if the value was actually inserted.  Leave the set unchanged
	// and return false if the value was not inserted (perhaps because it
	// is already in the set or because the set has a fixed capacity and
	// is full).

bool Set::erase(const ItemType& value) {

	if (!(contains(value)))
		return false; 
	else
	{
		m_array[m_position] = m_array[m_size - 1]; // last value gets placed to fill the whole. 
		m_size--;
		//m_array[m_size] =  // replace end of array with empty string. 
		return true; 
	}
}
	// Remove the value from the set if present.  Return true if the
	// value was removed; otherwise, leave the set unchanged and
	// return false.

bool Set::contains(const ItemType& value)
{
	if (empty())
		return false; // empty set

	for (int i = 0; i < m_size; i++)
	{
		if (m_array[i] == value)
		{
			m_position = i;
			return true;
		}
	}
	return false; // value doesnt exist in set. 
}

bool Set::get(int i, ItemType& value) const {

	if (i >= 0 && i < size())
	{

		value = m_array[i];
		//value now equals to whatever i index was passed in. 
		return true;
	}
	

	return false;



}
	

void Set::swap(Set& other) 
{

	Set temp; //Swap array content
	for (int i = 0; i < DEFAULT_MAX_ITEMS; i++)
	{
	temp.m_array[i] = this->m_array[i];
	this->m_array[i] = other.m_array[i];
	other.m_array[i] = temp.m_array[i];
	}

	temp.m_size = this->m_size; //Swap array sizes
	m_size = other.m_size; 
	other.m_size = temp.m_size; 
}


void Set::dump() const {

	if (empty())
		std::cerr << "Nothing here!" << std::endl;

	for (int i = 0; i < m_size; i++)
		std::cerr << m_array[i] << std::endl;


}
