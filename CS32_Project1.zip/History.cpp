#include "History.h"
#include "globals.h"
#include <iostream>
using namespace std; 


History::History(int nRows, int nCols)
{
	m_nRows = nRows; 
	m_nCols = nCols; 
	
	//constructor fills history deadbots with dots to the size of arena

	int r;
	int c;


	for (r = 0; r < nRows; r++)
	{
		for (c = 0; c < nCols; c++)
		{
			deadbots[r][c] = '.';
		}
	}
}





bool History::record(int r, int c) 
{	
	// check if r is out of bounds
	if (r > MAXROWS || r <= 0 || c <= 0 || c > MAXCOLS)
		return false; 


	if (deadbots[r - 1][c - 1] == '.')
		deadbots[r - 1][c - 1] = 'A';
	else if (deadbots[r - 1][c - 1] >= 'A' && deadbots[r - 1][c - 1] < 'Z')
		deadbots[r - 1][c - 1]++; 

	return true;

}

void History::display() const 
{
	clearScreen();
	int r;
	int c;

	

	for (r = 0; r < m_nRows; r++)
	{
		for (c = 0; c < m_nCols; c++)
			cout << deadbots[r][c];
		cout << endl;

	}

	cout << endl; //empty line


}

