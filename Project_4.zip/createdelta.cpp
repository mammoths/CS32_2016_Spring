#include <iostream>
#include <fstream>
#include <string>
#include <list>
#include "hashtable.h"
using namespace std;

void createDelta(istream& oldf, istream& newf, ostream& deltaf);

void createDelta(istream& oldf, istream& newf, ostream& deltaf)
{
	string deltastring;
	HashTable oldtable;
	string oldstring;
	string newstring;



	//getline(oldf, dummy);	//Takes care of case in just reading one string. 
	//oldstring += dummy;

	string dummy;
	while (getline(oldf, dummy))
	{
		oldstring += dummy;
		if (!oldf.eof())
			oldstring.push_back('\n');
	};


	while (getline(newf, dummy))
	{
		newstring += dummy;
		if (!newf.eof())
			newstring.push_back('\n');
	};




	const int sequenceLength = 5;
	char sequence[sequenceLength + 1];
	int counter = 0;

	//insertion of old data into hash table. 

	for (size_t i = 0; i < oldstring.length() - 1; i++)
	{
		sequence[counter] = oldstring[i];
		counter++;

		if (counter == sequenceLength || i == oldstring.length() - 1)
		{
			sequence[counter] = '\0';
			oldtable.insertHash(i - counter + 1, sequence);

			for (int i = 0; i < sequenceLength; i++)
			{
				sequence[i] = '\0';
			}
			counter = 0;
		}

	}

	//processing new string


	int len = 0;
	int hashIndex = 0;
	string temp = "";
	string addTemp = "";
	int startOffset, prevOffset, currentOffset, lastAdd;
	lastAdd = startOffset = prevOffset = currentOffset = -1;
	bool prevAdd = false;

	for (int j = 0; j < newstring.length(); j++)
	{
		startOffset = prevOffset = currentOffset = -1;
		len = 0;
		temp = newstring.substr(j, sequenceLength); // We don't care about what J is in the search hash. 

		if (oldtable.searchHash(startOffset, temp))
		{
			if (prevAdd && addTemp.length() >= 2)
			{
				//fix long add string

				//erase up until the A of add instruction
				deltastring.erase(deltastring.length() - 3);

				//add the length of the fixed add instruction
				deltastring += to_string(addTemp.length());
				deltastring.push_back(':');

				//add the sequence of characters
				deltastring += addTemp;
			}
			prevAdd = false;
			//cerr << "Found the subsequence " << temp << " at offset " << startOffset << endl;
			currentOffset = startOffset;
			len += sequenceLength;

			while (oldtable.searchHash(currentOffset, temp))
			{
				j += sequenceLength;
				temp = newstring.substr(j, sequenceLength);
				//	cerr << "Trying to find the subsequence " << temp << " in the hash table " << endl;
				prevOffset = currentOffset;
				if (oldtable.searchHash(currentOffset, temp))
				{
					if (currentOffset != (prevOffset + sequenceLength))
					{
						//cerr << " Found " << temp << " but it was not continuous with the previous substring." << endl;
						break;
					}
					else
					{
						//cerr << " Found " << temp << " in the hashTable with offset " << currentOffset << endl;
						len += sequenceLength;
					}
				}

			}
			if (currentOffset == prevOffset + sequenceLength)
			{
				//cerr << "Failed to find the substring " << temp << " in the hash table." << endl;
			}
			deltastring += "C" + to_string(len) + "," + to_string(startOffset);
			j -= 1;
			//	cerr << "We will copy a total of " << len << " from offset " << startOffset << " to offset " << currentOffset + len << endl;

		}

		else
		{
			//prepare long add instruction
			if (deltastring.length() >= 3 && prevAdd)
			{
				addTemp.push_back(newstring[j]);

				if (j == newstring.length() - 1)
				{
					//fix long add string
					//erase up until the A of add instruction
					deltastring.erase(deltastring.length() - 3);

					//add the length of the fixed add instruction
					deltastring += to_string(addTemp.length());
					deltastring.push_back(':');
					//add the sequence of characters
					deltastring += addTemp;
				}
				continue;
			}
			//cerr << "Couldn't find! So we will add " << newstring[j] << endl;
			addTemp = "";
			deltastring += "A1:";
			deltastring.push_back(newstring[j]);
			addTemp.push_back(newstring[j]);
			prevAdd = true;
		}
	}

//	cout << deltastring;
	deltaf << deltastring;
}
