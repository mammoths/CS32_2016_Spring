#include <iostream>
#include <fstream>
using namespace std; 


bool applyDelta(istream& oldf, istream& deltaf, ostream& newf);
bool getInt(istream& inf, int& n);
bool getCommand(istream& inf, char& cmd, int& length, int& offset);




bool applyDelta(istream& oldf, istream& deltaf, ostream& newf)
{
	char commandtemp = ' ';
	int lengthtemp = 0;
	int offsettemp = 0; 

	

	while (commandtemp != 'x')
	{
		if (!(getCommand(deltaf, commandtemp, lengthtemp, offsettemp)))
		{
			cerr << "Something wrong here!" << endl; 
			return false;
		}

		if (commandtemp == 'A')
		{
			char c;
			for (int i = 0; i < lengthtemp; i++)
			{
				
				deltaf.get(c);
			//	cout << "Adding the character " << c << endl;
				newf << c;
			}
			// add lengthtemp amount of characters to newf from delta. 
		}

		if (commandtemp == 'C')
		{
		
			// go to index at offsettemp
			// for loop lengthtemp times to copy the characters from oldf to newf

			//first iterate to get to the index of what you wanna copy by way of get?

			//oldf.seekg(offsettemp);


			char c;
		
			oldf.seekg(offsettemp);
			/*for (int i = 0; i < offsettemp; i++)
			{
				oldf.get(c); 
			}*/
		
			//cerr << "The offset we are copying from is " << offsettemp << endl; 


			for (int i = 0; i < lengthtemp; i++)
			{
				oldf.get(c); 
			//	cerr << "The character at " << offsettemp + i << " is: " << c << endl; 
				newf << c;
			}
		
			oldf.seekg(0);
		}



	}
	return true;

}


bool getInt(istream& inf, int& n)
{
	char ch;
	if (!inf.get(ch) || !isascii(ch) || !isdigit(ch))
		return false;
	inf.unget();
	inf >> n; // inf puts the integer value into n. 
	return true;
}

bool getCommand(istream& inf, char& cmd, int& length, int& offset)
{
	if (!inf.get(cmd) || (cmd == '\n'  &&  !inf.get(cmd)))
	{
		
		cmd = 'x';  // signals end of file
		return true;
	}
	char ch;
	switch (cmd)
	{ 
		cin >> noskipws;
	case 'A':
		return getInt(inf, length) && inf.get(ch) && ch == ':';
	case 'C':
		return getInt(inf, length) && inf.get(ch) && ch == ',' && getInt(inf, offset);
	}
	return false;
}
