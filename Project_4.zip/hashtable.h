#ifndef HASHTABLE_INCLUDED
#define HASHTABLE_INCLUDED
#include <string>
#include <list>
#define NUM_BUCK 300
using namespace std;


class HashTable
{

public:
	HashTable()
	{}

	void insertHash(int offset, string sequence);
	bool searchHash(int &offset, string sequence);
	void printTable();
private:
	list<pair<string, int>> m_buckets[NUM_BUCK];


};






#endif
