#include "hashtable.h"
#include <iostream>
#include <functional>

void stringhasher(const string &hashMe, unsigned int &bucket)
{
	hash<string>str_hash;
	unsigned int hashValue = str_hash(hashMe);
	bucket = hashValue % NUM_BUCK;
}


void HashTable::insertHash(int offset, string sequence)
{
	unsigned int bucket;
	stringhasher(sequence, bucket); // Hashes string sequence
	m_buckets[bucket].push_back(pair<string, int>(sequence, offset));
	
}



bool HashTable::searchHash(int &offset, string sequence) // if sequence is in the table return true
{
	unsigned int bucket;
	stringhasher(sequence, bucket); 

	for (pair<string, int>&p : m_buckets[bucket]) // Find the sequence
	{
		if (p.first == sequence)
		{
		
			offset = p.second;
			return true;
		}
		
	}

	offset = -1;
	return false; // Does not exist in table. 
	

}




void HashTable::printTable()
{
	for (int i = 0; i < NUM_BUCK; i++)
	{
		for (pair<string, int>&p : m_buckets[i])
		{
			cerr << "Index: " << i << ", Offset: " << p.second << ",  Seq: " << p.first << endl; 
		}
	}
}