#include "Set.h"
#include <iostream>


Set::Set():m_items(0)
{
	head = nullptr; 
	tail = nullptr;
	std::cerr << "Constructing! " << this << std::endl;
}

Set& Set::operator=(const Set& rhs)
{

	if (&rhs !=  this) // check aliasing
	{
		Node* p;
		p = head;
		while (p != nullptr)
		{
			Node *temp = p->m_next;
			delete p;
			p = temp;
			head = nullptr;
			tail = nullptr;
		}

		Set tempo = rhs; // Use Copy constructor to create temp other
		this->swap(tempo); // Swap with the temp other
	}
	std::cerr << "Constructing! " << this << std::endl; // remove this.. 
	return *this; 

}


Set::Set(const Set& other) 
{
	// Make new head with other head's value 

	m_items = other.m_items; 
	head = nullptr;
	tail = nullptr;
	if (m_items != 0)  //If set is empty, then copy nothing!

	{

		Node* otherset = other.tail;

		for (int k = 0; k < m_items; k++)
		{

			Node *p = new Node; // Make new node. 
			p->m_data = otherset->m_data;

			if (tail == nullptr) // first item of the list 
			{
				tail = p;
				tail->m_next = nullptr;
				tail->m_prev = nullptr;

			}
			else

			{
				head->m_prev = p;
				p->m_prev = nullptr; //head's previous will point to p. 
			}

			p->m_next = head; // The item after p will be what is currently head. 
			head = p; //head becomes p as current freshest value. 
			otherset = otherset->m_prev; 

		}

	}

	std::cerr << "Constructing!" << this <<  std::endl; 

}

Set::~Set(){

	Node* p;
	p = head;
	while (p != nullptr)
	{
		Node *temp = p->m_next;
		delete p;
		p = temp;
	}
	std::cerr << "Destructing!" << this << std::endl; 
}

bool Set::empty() const
{
	return size() == 0;
}

int Set::size() const
{
	return m_items;
}

bool Set::insert(const ItemType& value)
{
	if (contains(value))
	{
		std::cerr << value << " is a duplicate, so we did not add." << std::endl;
		return false;  // No set duplicates. 
	}

	// Item not found, so let's add it to the front of the list. 
	else 
	{
		Node* p;
		p = new Node;
		p->m_data = value;

		if (size() == 0) // if empty list, tail will be p. 
		{
			
			tail = p;
			tail->m_next = nullptr;
			tail->m_prev = nullptr;
			
			
		}
		else
		{
			head->m_prev = p; 
			p->m_prev = nullptr; //head's previous will point to p. 
		}

		p->m_next = head; // The item after p will be what is currently head. 
		head = p; //head becomes p as current freshest value. 

		m_items++;
		return true;
	}

}

bool Set::erase(const ItemType& value) 
{

	if (size() == 0) // if empty, delete nothin.
	{
		std::cerr << "Nothing here to erase!";
		return false; 
	}

	if (!contains(value))
		return false; 

	Node* p; 
	p = head; 

	
	////Searching for value// 
	while (p != nullptr) 
	{
		if (p->m_data == value)
			break;
		
		p = p->m_next;
		
	}

	
	///////////////////////////////////////
	/// Deleting first front item of list//
	//////////////////////////////////////

	if (p == head)
	{
		if (head->m_next == nullptr)
		{
			delete p;
			head = nullptr;
			tail = nullptr;
			m_items--;
			return true;
		}


		if (head->m_next != nullptr)  // if head is not the only item in the list
		{
			head->m_next->m_prev = nullptr; //next item no longer points to head, but to nullptr. 
			head = head->m_next; // head now points to item after it. 
			delete p;
			m_items--;
			return true; 
		}

		

	}

	//////////////////////////////////
	// deleting the end of list item // 
	////////////////////////////////////

	if (p == tail) 
	{
		if (p->m_prev != nullptr)
		{
			p->m_prev->m_next = nullptr; // Set second to last item to nullpointer
			tail = tail->m_prev; //Set the tail to point at second to last item.
		}

		//If it is the only item, it'll get deleted by the former function, ideally. 
		delete p; 
		m_items--;
		return true;
	}

  ///////////////////////////////////////////////////////
// deletion in the middle (p doesn't equal to head or tail)//
/////////////////////////////////////////////////////////////
	p->m_prev->m_next = p->m_next;
	p->m_next->m_prev = p->m_prev; 

	delete p; 
	m_items--;
	return true; 

}




bool Set::contains(const ItemType& value) const 
{
	
	if (size() == 0) // No items in list
		return false;


	Node *p; 
	p = head;


	while (p != nullptr)
	{	
		if (p->m_data != value)
			p = p->m_next;
		else break; 
	
	}
	
	if (p == nullptr)
		return false; // Item not contained. 

	if (p->m_data == value) 
		return true;
	

	

}


bool Set::get(int pos, ItemType& value) const 
{
	
	if (size() == 0) // empty so cant get anything
		return false; 

	if (pos < 0 || pos >= size()) //invalid values that are negative or >= size
		return false; 

	Node* p; 
	p = head; 

	for (int i = 0; i < pos; i++)
	{
		p = p->m_next;
	}

	value = p->m_data;
	return true; 



}


void Set::swap(Set& other) 
{
	Node* temphead;
	Node* temptail;

	temphead = other.head;
	temptail = other.tail;
	int tempitems = other.m_items;

	other.head = head;
	other.tail = tail; 
	other.m_items = m_items; 

	head = temphead;
	tail = temptail; 
	m_items = tempitems; 


}

void Set::dump()
{
	Node* p;
	p = head; 

	while (p != nullptr)
	{
		std::cerr << p->m_data << ": My current address is " << p << ". My previous address points to " << p->m_prev << ". My next address points to " << p->m_next << "." << std::endl;
		p = p->m_next;
	}

	std::cerr << "My tail is " << tail << ". My head is " << head << std::endl;


}


void unite(const Set& s1, const Set& s2, Set& result)
{

	Set temporary; //Create empty set. Should work even in the case of aliasing. 

		for (int i = 0; i < s1.size(); i++) 
		{
			ItemType temp;
			s1.get(i, temp);
			temporary.insert(temp);
		}
	
		for (int i = 0; i < s2.size(); i++)
		{
			ItemType temp2;
			s2.get(i, temp2);
			temporary.insert(temp2);
		}
	
		result.swap(temporary); 
}

void subtract(const Set& s1, const Set& s2, Set& result) 
{
	Set temporary = s1;


	for (int i = 0; i < s2.size(); i++)
	{
		ItemType temp; 
		s2.get(i, temp);

		if (temporary.contains(temp))
		temporary.erase(temp);
	}

	result.swap(temporary);
	
}
