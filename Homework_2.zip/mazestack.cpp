#include <stack>
#include <iostream>


using namespace std;


int main()
{
	bool pathExists(char maze[][10], int sr, int sc, int er, int ec);
	char maze[10][10] = {
		{ 'X','X','X','X','X','X','X','X','X','X' },
		{ 'X','.','.','.','.','.','.','.','.','X' },
		{ 'X','X','.','X','.','X','X','X','X','X' },
		{ 'X','.','.','X','.','X','.','.','.','X' },
		{ 'X','.','.','X','.','.','.','X','.','X' },
		{ 'X','X','X','X','.','X','X','X','.','X' },
		{ 'X','.','X','.','.','.','.','X','X','X' },
		{ 'X','.','.','X','X','.','X','X','.','X' },
		{ 'X','.','.','.','X','.','.','.','.','X' },
		{ 'X','X','X','X','X','X','X','X','X','X' }
	};

	if (pathExists(maze, 6, 4, 1, 1))
		cout << "Solvable!" << endl;
	else
		cout << "Out of luck!" << endl;
}


class Coord
{
public:
	Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
	int r() const { return m_r; }
	int c() const { return m_c; }
private:
	int m_r;
	int m_c;
};

bool pathExists(char maze[][10], int sr, int sc, int er, int ec)
{
	stack<Coord> coordStack; // Declare stack of coords
	Coord end(er, ec); 
	Coord start(sr, sc); 

	coordStack.push(start); // push starting coordinates
	maze[sr][sc] = '@'; // change character to indicate encounter


	while (!(coordStack.empty()))

	{
		Coord current = coordStack.top(); 
		const int cr = current.r(); 
		const int cc = current.c(); 
		
		cout << '(' << cr << ", " << cc << ')' << endl;
		coordStack.pop();

		if (cr == er && cc == cc)
			return true; 

		if (maze[cr - 1][cc] == '.') //North
		{
			coordStack.push(Coord(cr - 1, cc));
			maze[cr - 1][cc] = '@';
		}

		if (maze[cr][cc + 1] == '.') //East
		{
			coordStack.push(Coord(cr, cc + 1));
			maze[cr][cc + 1] = '@'; 

		}

		if (maze[cr+1][cc] == '.') // South
		{
			coordStack.push(Coord(cr, cc + 1));
			maze[cr+1][cc] = '@';
		}

		if (maze[cr][cc - 1] == '.') // West
		{
			coordStack.push(Coord(cr, cc - 1));
			maze[cr][cc - 1] = '@';
		}


	}
	return false;
}
