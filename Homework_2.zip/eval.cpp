#include <iostream>
#include <string>
#include <stack>
#include <cassert>
using namespace std;



int evaluate(string infix, string& postfix, bool& result);
string converter(string infix, string &postfix);



/*bool isValid(string infix)
{ 

	int parencounter1 = 0;
	int parencounter2 = 0; 

	for (int i = 0; i < infix.size(); i++)
	{

		if (infix[i] == '(')
		{
			parencounter1++;
			continue;
		}

		else if (infix[i] == ')')
		{
			parencounter2++;
			if (parencounter2 > parencounter1)
			{
				cerr << "Invalid because there are misplaced parens." << endl; return false;
			}
			continue;
		}

		/*else if (infix[i] == 'T' || infix[i] == 'F')
		{
			if (infix[i++] == 'T' || infix[i++] == 'F')
			{
				cerr << "current char is " << infix[i] << " and next char is " << infix[i++];
				cerr << "Invalid because two TFs together" << endl;
				return false;
			}
			continue;
		}


		else if (infix[i] != '&' || infix[i] !=  '|' || infix[i] != '!' || infix[i] != ' ')
		{
			return false;
		}
			
	}
	cerr << "All good." << endl; 
	return true; 
}

*/



string converter(string infix, string &postfix) // so far assuming if string is valid.. 
{


	postfix = "";
	stack <char> op;

	int paren1counter = 0;
	int paren2counter = 0;

	int size1 = infix.size();
	for (int i = 0; i < size1; i++)
	{

		switch (infix[i])
		{

		case 'T':
		case 'F':
			postfix += infix[i];
			cerr << "Adding " << infix[i] << ". Now we have " << postfix << "." << endl;

			break;


		case '(':
			paren1counter++;

			op.push(infix[i]);
			break;

		case ')':

			paren2counter++;
			if (paren1counter < paren2counter) return "Invalid infix. Mismatch Parentheses.";



			while (op.top() != '(')
			{
				postfix += op.top();
				op.pop();
			}
			op.pop();
			break;

		case '!':
			
			while (!(op.empty()) && op.top() != '(' &&  op.top() != '&' && op.top() != '|' )
			{
				cerr << infix[i] << " is higher than & and |. It must be less than equal to the top value, which is: " << op.top() << ". " << endl;
				cerr << "Now Adding: " << op.top() << endl;
				postfix += op.top();
				op.pop();
			}
			cerr << "Breaking while loop and now pushing " << infix[i] << " to the stack." << endl;
			op.push(infix[i]);
			break;

		case '&':

			while (!(op.empty()) && op.top() != '(' && op.top() != '|')
			{
				cerr << infix[i] << " is higher than |, but less than '!'. It must be less than or equal to the top value, which is: " << op.top() << ". " << endl;
				cerr << "Now Adding: " << op.top() << endl;
				postfix += op.top();
				op.pop();
			}
			cerr << "Breaking while loop and now pushing " << infix[i] << " to the stack." << endl;
			op.push(infix[i]);
			break;


		case '|':

			while (!(op.empty()) && op.top() != '(')
			{
				cerr << infix[i] << " is the lower than ! and &. It must be less than or equal to " << op.top() << ". " << endl;
				cerr << "Now Adding: " << op.top() << endl;
				postfix += op.top();
				op.pop();
			}

			cerr << "Breaking while loop" << endl;
			op.push(infix[i]);
			break;
	}
}
	while (!(op.empty()))
	{
		postfix += op.top();
		op.pop();

	}


	return postfix;
}


////////////////////////////////////////////////////
int evaluate(string infix, string& postfix, bool& result)
{
	

	postfix = converter(infix, postfix);
	cerr << "Acquired postfix. Evaluating " << postfix <<" now." << endl;
	stack <bool> eval;
	
	int size = postfix.size(); 
	bool placeholder = true; 
	for ( int i = 0; i < size; i++)
	{
		if (postfix[i] == 'T')
		{
			cerr << "The value is " << postfix[i] << ". Pushing it onto the stack now." << endl; 
			eval.push(true);
		}

		else if (postfix[i] == 'F')
		{
			cerr << "The value is " << postfix[i] << ". Pushing it onto the stack now." << endl;
			eval.push(false);
		}

		else if (postfix[i] == '!')
		{
			
			bool operandnot = eval.top();
			eval.pop();	
			cerr << "Evaluating " << postfix[i] << operandnot << endl;
			placeholder = (!operandnot);
			cerr << "We will push the result, " << placeholder << ", to the stack." << endl;
			eval.push(placeholder);
		}
		else
		{
			bool operand2 = eval.top();
			eval.pop();

			bool operand1 = eval.top();
			eval.pop();

			//Apply the operation of postfix[i] to op1 and op2. 

			if (postfix[i] == '&')
			{	
				cerr << "Evaluating " << operand1 << postfix[i] << operand2 << endl;
 				placeholder = (operand1 && operand2); 
				cerr << "We will push the result, " << placeholder << ", to the stack." << endl;
				eval.push(placeholder);
			}

			if (postfix[i] == '|')
			{
				cerr << "Evaluating " << operand1 << postfix[i] << operand2 << endl;
				placeholder = (operand1 || operand2);
				cerr << "We will push the result, " << placeholder << ", to the stack." << endl;
				eval.push(placeholder);
			}

		}

	}
	result = eval.top();
	return result; 
}
			



int main()
{
	string pf;
	bool answer;
	assert(evaluate("T| F", pf, answer) == 0 && pf == "TF|"  &&  answer);
	assert(evaluate("T|", pf, answer) == 1);
	assert(evaluate("F F", pf, answer) == 1);
	assert(evaluate("TF", pf, answer) == 1);
	assert(evaluate("()", pf, answer) == 1);
	assert(evaluate("T(F|T)", pf, answer) == 1);
	assert(evaluate("T(&T)", pf, answer) == 1);
	assert(evaluate("(T&(F|F)", pf, answer) == 1);
	assert(evaluate("", pf, answer) == 1);
	assert(evaluate("F  |  !F & (T&F) ", pf, answer) == 0
		&& pf == "FF!TF&&|"  &&  !answer);
	assert(evaluate(" F  ", pf, answer) == 0 && pf == "F"  &&  !answer);
	assert(evaluate("((T))", pf, answer) == 0 && pf == "T"  &&  answer);
	cout << "Passed all tests" << endl;
}

