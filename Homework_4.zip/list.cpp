

void listAll(string path, const File* f)  // two-parameter overload
{

	cout << path + "/" + f->name() << endl;

	if (f->files() == NULL)
	{
		return;
	}


	for (int i = 0; i < f->files()->size(); i++)
	{
		File* temp = f->files()->at(i);
		listAll(path + "/" + f->name(), temp); 

	}



}


