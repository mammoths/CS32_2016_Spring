// Game.cpp

#include "provided.h"

#include <iostream>
#include <string>
#include <stack>
using namespace std; 

class GameImpl
{
public:
	GameImpl(int nColumns, int nLevels, int N, Player* red, Player* black);
	bool completed(int& winner) const;
	bool takeTurn();
	void play();
	int checkerAt(int c, int r) const;

private:
	Scaffold* m_scaffold;
	Player* m_red;
	Player* m_black; 
	int turncounter;
	string m_redname;
	string m_blackname;
	int N_IN_A_ROW;
	stack<int> redlastlevel;
	stack<int> blacklastlevel;
	bool winCheck(int col, int lev, int color);
	bool WIN;
	int theWinner; 
	
	
};

GameImpl::GameImpl(int nColumns, int nLevels, int N, Player* red, Player* black)
	:m_red(red), m_black(black), turncounter(0), N_IN_A_ROW(N), theWinner(-1), WIN(false){

	m_scaffold = new Scaffold(nColumns, nLevels);
	m_redname = m_red->name(); 
	m_blackname = m_black->name();

	

}







bool GameImpl::completed(int& winner) const
{
	if (WIN == true)
	{
		winner = theWinner;
		
		string champion; 
		if (winner == RED)
			champion = m_redname;
		else if (winner == BLACK)
			champion = m_blackname; 
		
		cout << "Congratulations " << champion << "! You won!" << endl; 
		
		return true;

	}
	
	if (m_scaffold->numberEmpty() != 0)
		return false;
	else
	{
		cerr << "Out of moves! Tie game." << endl;
		winner = TIE_GAME;
		return true;
	}
	
}

bool GameImpl::takeTurn()
{
		if (turncounter % 2 == 0) // RED GOES ON EVEN NUMBERS.
		{
			int N = 1;
			N = m_red->chooseMove(*m_scaffold, N_IN_A_ROW, RED);
			cout << "Here is Red's Move!" << endl;
			m_scaffold->makeMove(N, RED);
			turncounter++;
	
			///////////getting level's value /////////////////////
			for (int i = 1; i <= m_scaffold->levels(); i++)
			{
				if (checkerAt(N , i) == VACANT)
				{
					redlastlevel.push(i-1);
					cerr << "Here's red's top level: " << redlastlevel.top() << endl; 
					break;
				}
			}

			if (checkerAt(N , m_scaffold->levels()) == RED) 
			{
				redlastlevel.push(m_scaffold->levels());
			}
			///////////////////////////////////////////////////////////

			if (winCheck(N, redlastlevel.top(), RED) == true)
			{
				theWinner = RED;
				//WIN = true; 

			}
			return true;
			
		}

		
	if (turncounter % 2 != 0)
		{
			int N = 1;
			N = m_black->chooseMove(*m_scaffold, N_IN_A_ROW, BLACK);
			cout << "Here is Black's move!" << endl;
			m_scaffold->makeMove(N, BLACK); 
			turncounter++;

			///////////getting level's value /////////////////////
			for (int i = 1; i <= m_scaffold->levels() ; i++)
			{
				if (checkerAt(N , i) == VACANT)
				{
					blacklastlevel.push(i -1);
				//	cerr << "Here's black's current top level: " << blacklastlevel.top() << endl; 
					break;
				}
			
			}

			if (checkerAt(N , m_scaffold->levels()) == BLACK) // Top item. Remember, these levels indicate their position on the INTERNAL GRID. 
			{
				blacklastlevel.push(m_scaffold->levels());
			//	cerr << "Here's black's current top level: " << blacklastlevel.top() << endl;
			}
			///////////////////////////////////////////////////////////



			if (winCheck(N, blacklastlevel.top(), BLACK) == true)
			{
				theWinner = BLACK;
				//WIN = true; 
			}
			return true;
		}
	
	
	return false;
}

void GameImpl::play()
{
	cout << "Let's play Connect " << N_IN_A_ROW << "! " << endl; 
	m_scaffold->display();
	cout << endl;


	int winner = -1; 
	while (completed(winner) == false)
	{
		takeTurn();
		m_scaffold->display();
	
		if (!WIN)
		{
			cout << "Press enter to continue!" << endl;
			cin.ignore();
		}
		

	}
	

	

}

int GameImpl::checkerAt(int c, int r) const
{
	return m_scaffold->checkerAt(c, r); 
}



bool GameImpl::winCheck(int col, int level, int color)
{


	if (!(m_scaffold->checkerAt(col, level) == color))
	{
		cerr << "Color at column and level didn't match passed in color!" << endl; return false;
	}

	  cerr << "Match! The value at (" << col << ", " << level << ") is " << color << "! Let's check for a winner." << endl;
	 
	//check horizontal
	int count = 0;
	for (int i = col; i <= m_scaffold->cols(); i++)
	{
		if (m_scaffold->checkerAt(i, level) == color) count++; else break; 
	}

	for (int i = 1; i < col; i++)
	{
		if (m_scaffold->checkerAt(i, level) == color) count++; else break; 
	}


	if (count >= N_IN_A_ROW) {
		cerr << count << " in a row! Horizontal Win!" << endl;
		WIN = true;
		return true;
	}


	//check vertical 
	count = 0;

	for (int i = 0; i < N_IN_A_ROW; i++)
	{
		if (m_scaffold->checkerAt(col, level - i) == color)
			count++;
		else
			break;
	}

	if (count >= N_IN_A_ROW)
	{
		cerr << count << " in a row! Vertical Win!" << endl;
		WIN = true;
		return true;
	}





   // Checking Diagonal Right


	count = 0;

   for (int i = 0; i < N_IN_A_ROW; i++)
   {
	   if (m_scaffold->checkerAt(col + i, level + i) == color)
		   count++;
	   else break;
   }

   for (int i = 1; i < N_IN_A_ROW; i++)
   {
	   if (m_scaffold->checkerAt(col - i, level - i) == color)
		   count++;
	   else break;
   }
	   if (count >= N_IN_A_ROW)
	   {
		   cerr << "Diagonal R Win!" << endl;
		   WIN = true;
		   return true;
	   }

   // Check Diagonal Left

	count = 0;

	for (int i = 0; i < N_IN_A_ROW; i++)
	{
		if (m_scaffold->checkerAt(col - i, level + i) == color) // Check Increasing Left
			count++; 
		else break;
	}

	for (int i = 1; i < N_IN_A_ROW; i++)
	{
		if (m_scaffold->checkerAt(col + i, level - i) == color) // Check Decreasing Right
			count++;
		else break;
	}

	   if (count >= N_IN_A_ROW)
	   {
		   cerr << "Diagonal L Win!" << endl;
		   WIN = true;
		   return true;
	   }

	   return false; 
   }





//******************** Game functions *******************************

// These functions simply delegate to GameImpl's functions.
// You probably don't want to change any of this code.

Game::Game(int nColumns, int nLevels, int N, Player* red, Player* black)
{
	m_impl = new GameImpl(nColumns, nLevels, N, red, black);
}

Game::~Game()
{
	delete m_impl;
}

bool Game::completed(int& winner) const
{
	return m_impl->completed(winner);
}

bool Game::takeTurn()
{
	return m_impl->takeTurn();
}

void Game::play()
{
	m_impl->play();
}

int Game::checkerAt(int c, int r) const
{
	return m_impl->checkerAt(c, r);
}


