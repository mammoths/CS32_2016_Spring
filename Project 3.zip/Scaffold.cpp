// Scaffold.cpp
#include <iostream>
#include "provided.h"
#include <vector>
#include <stack>
using namespace std;

class ScaffoldImpl
{
public:
	ScaffoldImpl(int nColumns, int nLevels);
	int cols() const;
	int levels() const;
	int numberEmpty() const;
	int checkerAt(int column, int level) const;
	void display() const;
	bool makeMove(int column, int color);
	int undoMove();
	

private:
	int m_nColumns;
	int m_nLevels;
	int m_nEmpty;
	vector<vector<int>> grid;
	stack<int> lastcolumn;
	stack<vector<vector<int>>> undostack;
};


ScaffoldImpl::ScaffoldImpl(int nColumns, int nLevels)
	:m_nLevels(nLevels), m_nColumns(nColumns), m_nEmpty(m_nColumns * m_nLevels)
{
	if (m_nLevels < 0 || m_nColumns < 0)
	{
		cerr << "Column or Level is not positive." << endl; 
			exit(1);
	}

	grid.resize(m_nColumns); // grid now has nLevels
	for (int i = 0; i < m_nColumns; i++)
		grid[i].resize(m_nLevels); // row i now has N columns

	for (int i = 0; i < m_nColumns; i++)
		for (int j = 0; j < m_nLevels; j++)
			grid[i][j] = VACANT; // initialize everything to vacant.


}



int ScaffoldImpl::cols() const
{
	return m_nColumns; 
}

int ScaffoldImpl::levels() const
{
	return m_nLevels;
}
int ScaffoldImpl::numberEmpty() const
{
	return m_nEmpty;  
}

int ScaffoldImpl::checkerAt(int column, int level) const // PASS IN WHAT THE USER WOULD PASS IN (NOT STARTING AT 0.)
{
	if (column <= 0 || level <= 0 || column > cols() || level > levels())
	{
		 //cerr << "Column or Level value is invalid! Returning VACANT." << endl;
		return VACANT;
	}


	
	switch (grid[column -1 ][m_nLevels - level]) { // this is gucci dont change!!

	case RED:
		return RED;
		break;
	case BLACK:
		return BLACK;
		break;
	default:
		return VACANT;
		break;
	}

}

void ScaffoldImpl::display() const
{
	int gridsize = m_nColumns * 2 + 1;
	vector <vector<char>> displaygrid;
	displaygrid.resize(gridsize);
	for (int i = 0; i < gridsize; i++)
		displaygrid[i].resize(m_nLevels + 1); // each row has a column now



	for (int i = 0; i < m_nLevels; i++)
	{
		for (int j = 0; j < gridsize; j++)
		{

			if (j % 2 == 0)
			{
				//cerr << "J is currently  " << j << endl;
				displaygrid[j][i] = '|';
			}
			else
			{
				if (grid[j / 2][i] == RED)
					displaygrid[j][i] = 'R';

				if (grid[j / 2][i] == BLACK)
					displaygrid[j][i] = 'B';
				if (grid[j / 2][i] == VACANT)
					displaygrid[j][i] = ' ';
			}

			cout << displaygrid[j][i];
		}
		cout << endl;
	}


	for (int j = 0; j < gridsize; j++)
	{
		if (j % 2 == 0)
			displaygrid[j][0] = '+';
		else
			displaygrid[j][0] = '-';
		cout << displaygrid[j][0];
	}

	cerr << endl;

	/*	///////////////////////////////////////////// GRID PRINTER
	//	cerr << endl << "=======================" << endl; // cool so this works!!

		cerr << endl;
		for (int k = 0; k < m_nLevels; k++)
		{
			for (int w = 0; w < m_nColumns; w++)
			{
				cerr << grid[w][k];
			}
			cerr << endl;
		}


		////////////////////////////////

	}
	*/
}
bool ScaffoldImpl::makeMove(int column, int color)
{
	if (column <= 0 || column > m_nColumns)
	{	
		cerr << "Your column isn't within range! Attempted column: " << column << endl;
		return false;
	}

	if (color != RED && color != BLACK)
		return false;
	



	for (int k = m_nLevels-1; k >= 0; k--)
	{
		if (grid[column - 1][k] == VACANT)
		{
			grid[column - 1][k] = color; 
			m_nEmpty--;
			undostack.push(grid);
			lastcolumn.push(column - 1);
			return true;
		}
	}




		cerr << "This column is now full" << endl; 
		return false; 


	

}

int ScaffoldImpl::undoMove()
{

	if (grid.empty())
		return 0;
	else
	{

		undostack.pop();
		grid = undostack.top();
		m_nEmpty++;
		
		int lastcol = lastcolumn.top();
		lastcolumn.pop();
		return lastcol;


	}
}


//******************** Scaffold functions *******************************

// These functions simply delegate to ScaffoldImpl's functions.
// You probably don't want to change any of this code.

Scaffold::Scaffold(int nColumns, int nLevels)
{
	m_impl = new ScaffoldImpl(nColumns, nLevels);
}

Scaffold::~Scaffold()
{
	delete m_impl;
}

Scaffold::Scaffold(const Scaffold& other)
{
	m_impl = new ScaffoldImpl(*other.m_impl);
}

Scaffold& Scaffold::operator=(const Scaffold& rhs)
{
	if (this != &rhs)
	{
		Scaffold temp(rhs);
		swap(m_impl, temp.m_impl);
	}
	return *this;
}

int Scaffold::cols() const
{
	return m_impl->cols();
}

int Scaffold::levels() const
{
	return m_impl->levels();
}

int Scaffold::numberEmpty() const
{
	return m_impl->numberEmpty();
}

int Scaffold::checkerAt(int column, int level) const
{
	return m_impl->checkerAt(column, level);
}

void Scaffold::display() const
{
	m_impl->display();
}

bool Scaffold::makeMove(int column, int color)
{
	return m_impl->makeMove(column, color);
}

int Scaffold::undoMove()
{
	return m_impl->undoMove();
}
