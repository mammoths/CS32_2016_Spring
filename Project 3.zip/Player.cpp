// Player.cpp

#include "provided.h"
#include <string>
#include <iostream>
#include <stack>

using namespace std;


class HumanPlayerImpl
{
public:
	int chooseMove(const Scaffold& s, int N, int color);
};

class BadPlayerImpl
{
public:
	int chooseMove(const Scaffold& s, int N, int color);



};

class SmartPlayerImpl
{
public:
	int chooseMove(const Scaffold& s, int N, int color);

	int rating(int N, int color, const Scaffold &s, int col, int level);


	
};

///////////////////////////////////////////////////

int HumanPlayerImpl::chooseMove(const Scaffold& s, int N, int color)
{
	Scaffold copy = s; 
	int move = 0;
	cerr <<  "Choose a column!" << endl;
	cin >> move;

	
	while (copy.makeMove(move, color) == false)
	{
		cerr << "Your column wasn't valid. Try again :-) " << endl;
		cin >> move;
	}
	return move;

}

int BadPlayerImpl::chooseMove(const Scaffold& s, int N, int color)
{

	Scaffold copy = s;
	for (int move = 1; move <= s.cols(); move++)
	{
		if (copy.makeMove(move, color) == true)
			return move;
	}

	return -1; // no move possible.

}
/*

int SmartPlayerImpl::rating(int N, int color, const Scaffold &s, int col, int level)
{
	cerr << "Color is " << color << endl; 
	
		if (winCheck(s, N, col, level, color))
			return 1;
		else if (winCheck(s, N, col, level, !color))
			return -1;
		else return 0; 
	
}

*/


int SmartPlayerImpl::chooseMove(const Scaffold& s, int N, int color)
{

	Scaffold copy = s;
	for (int move = 1; move <= s.cols(); move++)
	{
		if (copy.makeMove(move, color) == true)
			return move;
	}

	return -1; // no move possible.

}
	/* BELOW IS A FAILED SMART PLAYER :-( 
// if color is RED/BLACK
	if (playercolor == robotcolor) {
		Scaffold copy = s;
		for (int i = 1; i <= s.cols(); i++)
		{
			copy.makeMove(i, robotcolor);
			int latestlevel;

			///////////getting level's value /////////////////////
			for (int i = 1; i <= s.levels(); i++)
			{
				if (s.checkerAt(N, i) == VACANT)
				{
					latestlevel = i - 1;
					break;
				}
			}

			if (s.checkerAt(N, s.levels()) == robotcolor)
			{
				latestlevel = s.levels();
			}
			///////////////////////////////////////////////////////////


			int rate = rating(N, robotcolor, s, s.cols(), s.levels());

			// winning move
			if (rate == 1)
				return i;
		
			else if (rate == 0) {
				// recursive magic
				return chooseMove(copy, N, humancolor);
			}
			
			copy.undoMove();
		
		}
		return 1; 
	

		// if you et here al moves were losing so just pick one valid one
	}
	// OTHER COLOR
	if (playercolor == humancolor)
	{
		Scaffold copy = s; 
		for (int i = 1; i <= s.cols(); i++)
		{
			copy.makeMove(i, humancolor);
			int latestlevel;

			///////////getting level's value /////////////////////
			for (int i = 1; i <= s.levels(); i++)
			{
				if (s.checkerAt(N, i) == VACANT)
				{
					latestlevel = i - 1;
					break;
				}
			}

			if (s.checkerAt(N, s.levels()) == humancolor)
			{
				latestlevel = s.levels();
			}
			///////////////////////////////////////////////////////////

			int rate = rating(N, humancolor, s, s.cols(), s.levels());

			// winning move
			if (rate == -1)
				return i;
			else if (rate == 0) {
				return chooseMove(copy, N, robotcolor);
			}

			copy.undoMove();
		}
		// if you are here all moves were losing so just piuck one valid one
		return 2; 

		}
	
		
		// Everything is the same as the computer except that it is opposite logic
	}
		// makes the move
			// evaluate the move
			// if it was a winning move then return the col
			// else if it was a tie, recurse
			
		// undo move

		// if you get here, they were all losing moves just pick one valid one and lose

	 // if you want it to be better add depth which will 
	// subtract as you recurse. winning moves that have bigger depth are prefered because you won earlier



	


*/



//******************** Player derived class functions *************************

// These functions simply delegate to the Impl classes' functions.
// You probably don't want to change any of this code.

HumanPlayer::HumanPlayer(string nm)
	: Player(nm)
{
	m_impl = new HumanPlayerImpl;
}

HumanPlayer::~HumanPlayer()
{
	delete m_impl;
}

int HumanPlayer::chooseMove(const Scaffold& s, int N, int color)
{
	return m_impl->chooseMove(s, N, color);
}

BadPlayer::BadPlayer(string nm)
	: Player(nm)
{
	m_impl = new BadPlayerImpl;
}

BadPlayer::~BadPlayer()
{
	delete m_impl;
}

int BadPlayer::chooseMove(const Scaffold& s, int N, int color)
{
	return m_impl->chooseMove(s, N, color);
}

SmartPlayer::SmartPlayer(string nm)
	: Player(nm)
{
	m_impl = new SmartPlayerImpl;
}

SmartPlayer::~SmartPlayer()
{
	delete m_impl;
}

int SmartPlayer::chooseMove(const Scaffold& s, int N, int color)
{
	return m_impl->chooseMove(s, N, color);
}
