

class Creature 
{
public:

	Creature(const string name)
	:m_name(name){}
	virtual ~Creature() = 0 {};
	virtual string name() const { return m_name;  }
	virtual string move() const = 0 {};
	virtual bool isMortal() const  { return true; }
	
private:
	string m_name;
};



class Phoenix : public Creature
{
public:
	Phoenix(string name) 
		: Creature(name) {}
	virtual ~Phoenix(){ cout << "Destroying " << name() << " the phoenix." << endl; }
	virtual bool isMortal() const { return false; }
	virtual string move() const { return "fly"; }
};


class Giant : public Creature
{
public:
	Giant(string name, int weight)
		:Creature(name), m_weight(weight) {}
	virtual ~Giant() { cout << "Destroying " << name() << " the giant." << endl; }
	virtual string move() const
	{
		if (m_weight < 20)
			return "tromp";
		else return "lumber";
	}

	
private:
	int m_weight;
};



class Centaur : public Creature
{
public:
	Centaur(string name)
		:Creature(name)	{}
	virtual ~Centaur() { cout << "Destroying " << name() << " the centaur." << endl; }
	virtual string move() const { return "trot"; }
};

