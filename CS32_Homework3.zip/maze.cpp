
class Coord
{
public:
Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
int r() const { return m_r; }
int c() const { return m_c; }
private:
int m_r;
int m_c;
};



bool pathExists(char maze[][10], int sr, int sc, int er, int ec)
{
	if (sr < 0 || sc < 0 || er < 0 || ec < 0 || maze[sr][sc] != '.' || maze[er][ec] != '.')
		return false; // check if the values aren't valid.

	Coord current(sr, sc);
	const int cr = current.r();
	const int cc = current.c();

	if (sr == er && sc == ec)
		return true;


	maze[sr][sc] = '@'; // change character to indicate encounter

	// Check each direction:

	if (maze[cr + 1][cc] == '.')
	{
		if (pathExists(maze, cr + 1, cc, er, ec))
			return true;
	}

	if (maze[cr - 1][cc] == '.')
	{
		if (pathExists(maze, cr - 1, cc, er, ec))
			return true;

	}

	if (maze[cr][cc + 1] == '.')
	{
		if (pathExists(maze, cr, cc + 1, er, ec))
			return true;
	}

	if (maze[cr][cc - 1] == '.')
	{
		if (pathExists(maze, cr, cc - 1, er, ec))
			return true;
	}

	return false;

}

