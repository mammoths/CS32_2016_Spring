
bool somePredicate(string s)
{
	if 	(s.size() == 4)
	return true; 

	else return false;
}


// Return false if the somePredicate function returns false for at
// least one of the array elements; return true otherwise.
bool allTrue(const string a[], int n)
{


	if (n == 0)
	return true;

		if (somePredicate(a[n - 1]) == false)
			return false;
		else
		{
			n--;
			return allTrue(a, n);
		}
	

}


// Return the number of elements in the array for which the
// somePredicate function returns false.
int countFalse(const string a[], int n)
{
	int counter = 0; 
	if (n == 0) return counter; 

	if (somePredicate(a[n-1]) == false)
		counter++; 

	n--;
	int temp = countFalse(a, n);
	counter += temp; 
	return counter; 
}


// Return the subscript of the first element in the array for which
// the somePredicate function returns false.  If there is no such
// element, return -1.
int firstFalse(const string a[], int n)
{

	if (somePredicate(a[0]) == false)
		return 0; 

	if (&a[0] == &a[n - 1]) // end of array, nothing was false. 
		return -1; 

	if (firstFalse(a + 1, n - 1) == -1)
		return -1;

	int index = firstFalse(a + 1, n - 1) + 1;

	if (index >= 0)
		return index;
	else
		return -1; 


}


// Return the subscript of the least string in the array (i.e.,
// the smallest subscript m such that a[m] <= a[k] for all
// k from 0 to n-1).  If the array has no elements to examine,
// return -1.

int indexOfLeast(const string a[], int n)
{
	if (n <= 0)
		return -1;

	if (n == 1)
		return 0; // base case


	int index = indexOfLeast(a + 1, n - 1);

	
	if (a[index + 1] < a[0])
	{
		
		return index + 1;
	}

	else
	{
		
		return 0;
	}
}



// If all n2 elements of a2 appear in the n1 element array a1, in
// the same order (though not necessarily consecutively), then
// return true; otherwise (i.e., if the array a1 does not include
// a2 as a not-necessarily-contiguous subsequence), return false.
// (Of course, if a2 is empty (i.e., n2 is 0), return true.)
// For example, if a1 is the 7 element array
//    "stan" "kyle" "cartman" "kenny" "kyle" "cartman" "butters"
// then the function should return true if a2 is
//    "kyle" "kenny" "butters"
// or
//    "kyle" "cartman" "cartman"
// and it should return false if a2 is
//    "kyle" "butters" "kenny"
// or
//    "stan" "kenny" "kenny"
bool includes(const string a1[], int n1, const string a2[], int n2)
{
	if (n2 == 0)  return 1;
	if (n1 < n2) return 0;
	
	
	if (*a1 == *a2)
	{
		
		return includes(a1 + 1, n1 - 1, a2+1, n2-1);
	}
	else
	{
		return  includes(a1 + 1, n1 - 1, a2, n2);
	}
	}



	